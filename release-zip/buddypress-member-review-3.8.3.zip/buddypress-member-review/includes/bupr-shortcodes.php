<?php // phpcs:disable WordPress.Files.FileName.InvalidClassFileName
/**
 * Class to add reviews shortcode.
 *
 * @since    1.0.0
 * @author   Wbcom Designs
 * @package  BuddyPress_Member_Reviews
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'BUPR_Shortcodes' ) ) {

	/**
	 * Class to serve AJAX Calls.
	 *
	 * @author   Wbcom Designs
	 * @since    1.0.0
	 */
	class BUPR_Shortcodes {

		/**
		 * Constructor.
		 *
		 * @since    1.0.0
		 * @author   Wbcom Designs
		 */
		public function __construct() {
			add_shortcode( 'bupr_display_top_members', array( $this, 'bupr_display_top_members_display' ) );
			add_action( 'bupr_member_review_form', array( $this, 'bupr_display_review_form' ) );
		}

		/**
		 * Display top members on front-end using optimized SQL queries for ratings and reviews.
		 * Added filters for future extensibility.
		 *
		 * @since    1.0.9
		 * @author   Wbcom Designs
		 * @param    array $attrs Shortcode attributes.
		 * @return   string HTML output for top members display.
		 */
		public function bupr_display_top_members_display( $attrs ) {

			global $wpdb;

			// Extract shortcode attributes.
			$atts = shortcode_atts(
				apply_filters(
					'bupr_display_top_members_shortcode_atts',
					array(
						'title'        => '',
						'total_member' => 5,
						'type'         => 'top rated',
						'avatar'       => 'show',
					),
					$attrs
				),
				$attrs
			);

			$bupr_title     = apply_filters( 'bupr_shortcode_title', $atts['title'] );
			$member_limit   = apply_filters( 'bupr_shortcode_member_limit', $atts['total_member'] );
			$top_member     = apply_filters( 'bupr_shortcode_type', $atts['type'] );
			$avatar_display = apply_filters( 'bupr_shortcode_avatar', $atts['avatar'] );

			$output = '';

			// Determine the meta key based on the sorting type (top rated or most reviewed).
			$meta_key = ( 'top rated' === $top_member ) ? 'bupr_aggregate_rating' : 'bupr_review_count';
			$meta_key = apply_filters( 'bupr_shortcode_meta_key', $meta_key, $top_member );

			/*
			 * The CAST() in ORDER BY defeats the usermeta meta_key index, forcing a
			 * filesort of every row carrying the meta key. Cache the result set in the
			 * object cache, keyed on the group's last-changed token. The token moves in
			 * bupr_flush_top_members_cache() whenever aggregate rating/review-count
			 * meta changes (review status transition, trash/delete, batch recalc),
			 * which invalidates all variations at once.
			 */
			$cache_key = md5( $meta_key . '|' . (int) $member_limit ) . ':' . wp_cache_get_last_changed( 'bupr_top_members' );

			$bupr_user_data = wp_cache_get( $cache_key, 'bupr_top_members' );
			if ( false === $bupr_user_data ) {
				// Query to fetch users based on their aggregate rating or review count.
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Result cached in the object cache above.
				$bupr_user_data = $wpdb->get_results(
					$wpdb->prepare(
						"SELECT user_id, meta_value
					FROM {$wpdb->usermeta}
					WHERE meta_key = %s
					AND CAST(meta_value AS DECIMAL(10,2)) > 0
					ORDER BY CAST(meta_value AS DECIMAL(10,2)) DESC
					LIMIT %d",
						$meta_key,
						$member_limit
					)
				);
				wp_cache_set( $cache_key, $bupr_user_data, 'bupr_top_members', 15 * MINUTE_IN_SECONDS );
			}
			$top_members = apply_filters( 'bupr_shortcode_query_results', $bupr_user_data, $meta_key );

			$output .= '<div class="bupr-shortcode-top-members-contents bupr_members_review_setting">';
			$output .= '<h2>' . esc_html( $bupr_title ) . '</h2>';
			$output .= '<ul class="bupr-member-main">';

			// Display each top member.
			if ( ! empty( $top_members ) ) {
				foreach ( $top_members as $member ) {
					$user_id = apply_filters( 'bupr_shortcode_member_id', $member->user_id );

					// Get user's aggregate rating and review count from meta.
					$aggregate_rating = get_user_meta( $user_id, 'bupr_aggregate_rating', true );
					$review_count     = get_user_meta( $user_id, 'bupr_review_count', true );

					$aggregate_rating = apply_filters( 'bupr_shortcode_aggregate_rating', ( ! empty( $aggregate_rating ) ? round( $aggregate_rating, 2 ) : 0 ), $user_id );
					$review_count     = apply_filters( 'bupr_shortcode_review_count', ( ! empty( $review_count ) ? $review_count : 0 ), $user_id );

					$profile_url = bupr_member_url( $user_id );

					// Get global settings for review tab URL.
					global $bupr;
					$review_tab_slug = isset( $bupr['review_label_plural'] ) ? sanitize_title( $bupr['review_label_plural'] ) : 'reviews';
					$reviews_url     = $profile_url . $review_tab_slug . '/';

					// Display avatar and user link.
					$output .= '<li class="bupr-members">';
					if ( 'show' === $avatar_display ) {
						$output .= apply_filters( 'bupr_shortcode_avatar_display', '<div class="bupr-img-widget"><a href="' . esc_url( $profile_url ) . '">' . get_avatar( $user_id, 50 ) . '</a></div>', $user_id );
					}
					$output .= '<div class="bupr-content-widget">';
					// Display name, never the login (a login is half of a member's credentials).
					$display_name   = bp_core_get_user_displayname( $user_id );
					$members_profile = '<a href="' . esc_url( $profile_url ) . '">' . esc_html( $display_name ) . '</a>';
					$output .= '<div class="bupr-member-title">' . wp_kses_post( $members_profile ) . '</div>';

					/**
					 * Filter whether to show star ratings in shortcode.
					 * Pro addon sets this to false for Testimonial/Endorsement modes.
					 *
					 * @since 3.8.0
					 * @param bool $show_stars Whether to display star ratings. Default true.
					 * @param int  $user_id    The member's user ID.
					 */
					$show_stars = apply_filters( 'bupr_shortcode_show_stars', true, $user_id );

					if ( $show_stars ) {
						// Display star rating (5-star format) and review count.
						$stars_on   = floor( $aggregate_rating );
						$stars_half = ( $aggregate_rating - $stars_on >= 0.5 ) ? 1 : 0;
						$stars_off  = 5 - ( $stars_on + $stars_half );

						$output .= '<div class="bupr-member-rating">';
						for ( $i = 1; $i <= $stars_on; $i++ ) {
							$output .= apply_filters( 'bupr_shortcode_star_full', '<span class="fas fa-star bupr-star-rate"></span>', $user_id, $i );
						}
						if ( $stars_half ) {
							$output .= apply_filters( 'bupr_shortcode_star_half', '<span class="fas fa-star-half-alt bupr-star-rate"></span>', $user_id );
						}
						for ( $i = 1; $i <= $stars_off; $i++ ) {
							$output .= apply_filters( 'bupr_shortcode_star_empty', '<span class="far fa-star bupr-star-rate"></span>', $user_id );
						}
						$output .= '</div>';
					}

					/**
					 * Filter the item type label (reviews/testimonials/endorsements).
					 * Pro addon changes this based on review mode.
					 *
					 * @since 3.8.0
					 * @param string $label The item type label. Default 'reviews'.
					 * @param int    $count Review count, for choosing singular or plural (since 3.8.1).
					 */
					$item_label = apply_filters( 'bupr_item_type_label', _n( 'review', 'reviews', (int) $review_count, 'bp-member-reviews' ), (int) $review_count );

					$aggregate_rating = round( $aggregate_rating, 2 );
					$output          .= '<span class="bupr-meta">';

					if ( $show_stars ) {
						$review_count_link = '<a href="' . esc_url( $reviews_url ) . '" class="bupr-review-count-link">' . esc_html( $review_count ) . '</a>';
						/* translators: %1$s: rating; %2$s: review count; %3$s: item type label */
						$output .= apply_filters( 'bupr_shortcode_rating_text', sprintf( esc_html__( 'Rating: %1$s/5 (%2$s %3$s)', 'bp-member-reviews' ), esc_html( $aggregate_rating ), $review_count_link, esc_html( $item_label ) ), $user_id, $aggregate_rating, $review_count );
					} else {
						$review_count_link = '<a href="' . esc_url( $reviews_url ) . '" class="bupr-review-count-link">' . esc_html( $review_count ) . '</a>';
						/* translators: %1$s: review count; %2$s: item type label */
						$output .= apply_filters( 'bupr_shortcode_count_text', sprintf( esc_html__( '%1$s %2$s', 'bp-member-reviews' ), $review_count_link, esc_html( $item_label ) ), $user_id, $review_count );
					}
					$output .= '</span>';

					$output .= '</div></li>';
				}
			} else {
				$output .= apply_filters( 'bupr_shortcode_no_members_text', '<p>' . esc_html__( 'No members have been reviewed yet.', 'bp-member-reviews' ) . '</p>' );
			}

			$output .= '</ul>';
			$output .= '</div>';

			return apply_filters( 'bupr_shortcode_output', $output );
		}


		/**
		 * Sort member list according to max review.
		 *
		 * @since    1.0.9
		 * @author   Wbcom Designs
		 * @param    array $bupr_rating1 First rating array to compare.
		 * @param    array $bupr_rating2 Second rating array to compare.
		 * @return   int Comparison result.
		 */
		public function bupr_get_sort_max_review( $bupr_rating1, $bupr_rating2 ) {
			return strcmp( $bupr_rating2['max_review'], $bupr_rating1['max_review'] );
		}

		/**
		 * Sort member list according to max star.
		 *
		 * @since    1.0.9
		 * @author   Wbcom Designs
		 * @param    array $bupr_rating1 First rating array to compare.
		 * @param    array $bupr_rating2 Second rating array to compare.
		 * @return   int Comparison result.
		 */
		public function bupr_get_sort_max_stars( $bupr_rating1, $bupr_rating2 ) {
			return strcmp( $bupr_rating2['avg_rating'], $bupr_rating1['avg_rating'] );
		}
		/**
		 * Display add review form on front-end.
		 *
		 * @since    1.0.0
		 * @author   Wbcom Designs
		 */
		public function bupr_display_review_form() {
			global $bp;
			global $bupr;

			$login_user           = get_current_user_id();
			$bupr_spinner_src     = includes_url() . 'images/spinner.gif';
			$auto_approve_reviews = $bupr['auto_approve_reviews'];
			$review_label         = $bupr['review_label'];

			$bupr_review_succes = false;
			$bupr_flag          = false;
			$bupr_member        = array();

			// Setting default query arguments.
			$args = array(
				'exclude' => array( get_current_user_id() ), // Exclude current user directly.
				'fields'  => array( 'ID', 'display_name' ),  // Only get ID and display name.
				'number'  => 100, // Optional: Limit the number of users retrieved at a time.
			);

			// Apply a filter to the query arguments.
			$args = apply_filters( 'bupr_member_query_args', $args );

			$user_query = new WP_User_Query( $args );

			if ( ! empty( $user_query->get_results() ) ) {
				foreach ( $user_query->get_results() as $user ) {
					$user_info     = get_userdata( $user->ID );
					$bupr_member[] = array(
						'member_id'    => $user->ID,
						'member_name'  => $user->display_name,
						'member_roles' => $user_info->roles, // Fetch roles separately.
					);
				}
			}

			// Apply a filter to allow modification of the member array.
			$bupr_member = apply_filters( 'bupr_member_list', $bupr_member );

			$member_args = array(
				'post_type'      => 'review',
				// Only this author's own review of the member is needed.
				'posts_per_page' => 1,
				'no_found_rows'  => true,
				'post_status'    => array(
					'draft',
					'publish',
				),
				'author'         => $login_user,
				'category'       => 'bp-member',
				'meta_query'     => array(
					array(
						'key'     => 'linked_bp_member',
						'value'   => bp_displayed_user_id(),
						'compare' => '=',
					),
				),
			);

			$reviews_args = new WP_Query( $member_args );
			if ( ! bp_is_members_component() && ! bp_is_user() ) {
				$bp_template_option = bp_get_option( '_bp_theme_package_id' );
			}

			if ( 0 === bp_displayed_user_id() ) {
				$this->bupr_review_form( $login_user, $bupr_spinner_src, $bupr_review_succes, $bupr_flag, $bupr_member );
			} else {
				if ( 'no' === $bupr['multi_reviews'] ) {
					$user_post_count = $reviews_args->post_count;
				} else {
					$user_post_count = 0;
				}
				if ( 0 === $user_post_count ) {
					$this->bupr_review_form( $login_user, $bupr_spinner_src, $bupr_review_succes, $bupr_flag, $bupr_member );
				} else {
					$bp_template_option = bp_get_option( '_bp_theme_package_id' );
					if ( 'nouveau' === $bp_template_option ) {
						?>
							<div id="message" class="success bp-feedback bp-messages bp-template-notice">
								<span class="bp-icon" aria-hidden="true"></span>
					<?php } else { ?>
								<div id="message" class="info">
										<?php } ?>
								<?php
								if ( 'publish' === $reviews_args->posts[0]->post_status ) {
									/* translators: %s: */
									$message = sprintf( __( 'You already posted a %1$s for this member.', 'bp-member-reviews' ), $review_label );
								} elseif ( 'yes' === $auto_approve_reviews ) {
										/* translators: %s: */
										$message = sprintf( esc_html__( 'Thank you for taking time to write this wonderful %1$s.', 'bp-member-reviews' ), $review_label );
								} else {
									/* translators: %s: */
									$message = sprintf( esc_html__( 'Thank you for taking time to write this wonderful %1$s. Your %1$s will display after moderator\'s approval.', 'bp-member-reviews' ), $review_label );
								}
								?>
										<p><?php echo esc_html( $message ); ?> </p>
								</div> <!-- Close div for success/info message -->
							<?php
				}
			}
			wp_reset_postdata();
		}

		/**
		 * Check criteria
		 *
		 * @return bool
		 */
		public function bupr_criteria_is_enable() {
			global $bupr;
			$show_rating = false;
			foreach ( $bupr['active_rating_fields'] as $bupr_rating_fields ) {
				if ( $bupr['multi_criteria_allowed'] ) {
					$show_rating = true;
					return $show_rating;
				}
			}
			return $show_rating;
		}

		/**
		 * Bupr review form.
		 *
		 * @since    1.0.0
		 * @param    string $login_user             Login  User.
		 * @param    string $bupr_spinner_src       Spinner  User.
		 * @param    string $bupr_review_succes     Review Success.
		 * @param    int    $bupr_flag              Flag.
		 * @param    array  $bupr_member            Member array.
		 * @author   Wbcom Designs
		 */
		public function bupr_review_form( $login_user, $bupr_spinner_src, $bupr_review_succes, $bupr_flag, $bupr_member ) {
			global $bupr;
			$flag = false;
			if ( 'yes' === $bupr['anonymous_reviews'] ) {
				$flag = true;
			}
			$bp_template_option = bp_get_option( '_bp_theme_package_id' );
			if ( 'nouveau' === $bp_template_option ) {
				?>
				<div id="message" class="success add_review_msg success_review_msg bp-feedback bp-messages bp-template-notice">
					<span class="bp-icon" aria-hidden="true"></span>
				<?php } else { ?>
					<div id="message" class="success add_review_msg success_review_msg">
						<?php } ?>
						<p></p>
					</div>
					<?php
					if ( is_user_logged_in() ) {
						$user          = wp_get_current_user();
						$roles         = ( isset( $user->roles ) && ! empty( $user->roles ) ) ? $user->roles : array();
						$allowed_roles = isset( $bupr['exclude_given_members'] ) && is_array( $bupr['exclude_given_members'] ) ? $bupr['exclude_given_members'] : array();
						if ( ! empty( $allowed_roles ) && ! array_intersect( $roles, $allowed_roles ) ) {
							// User's role is NOT in the allowed reviewer roles list - block them.
							?>
						<div class="bupr_not_give_review">
								<p><?php esc_html_e( 'Sorry, You have not been given permission to review the user !!!', 'bp-member-reviews' ); ?></p>
						</div>
							<?php
						} else {
							?>
					<form action="" method="POST" id="bupr_review_form_public">
						<input type="hidden" value="<?php echo esc_attr( $bupr['rating_color'] ); ?>" class="bupr-display-rating-color">
						<div class="bp-member-add-form">
							<p>
							<?php
							/* translators: %s: */
							printf( esc_html__( 'Fill in details to submit %s', 'bp-member-reviews' ), esc_html( strtolower( $bupr['review_label'] ) ) );
							?>
							</p>
							<?php if ( 0 === bp_displayed_user_id() ) { ?>
								<p>
									<select name="bupr_member_id" id="bupr_member_review_id">
										<option value=""><?php esc_html_e( '--Select--', 'bp-member-reviews' ); ?></option>
								<?php
								foreach ( $bupr_member as $user ) {
									if ( bupr_roles_allow_review( get_current_user_id(), $user['member_id'] ) ) {
										echo '<option value="' . esc_attr( $user['member_id'] ) . '">' . esc_attr( $user['member_name'] ) . '</option>';
									}
								}
								?>
									</select><br/>
									<span class="bupr-error-fields">*<?php esc_html_e( 'This field is required.', 'bp-member-reviews' ); ?></span>
									</p>
							<?php } ?>
								

							<?php
							// Only show rating fields if active_rating_fields is not empty.
							// In Testimonial Mode, active_rating_fields is cleared by the Pro addon.
							$has_rating_fields = ! empty( $bupr['active_rating_fields'] );

							if ( $has_rating_fields ) {
								$bupr_display_rating = $this->bupr_criteria_is_enable();
								if ( true === $bupr_display_rating ) {
									$field_counter = 1;
									$flage         = true;
									if ( $bupr['multi_criteria_allowed'] ) {
										foreach ( $bupr['active_rating_fields'] as $bupr_rating_fields => $bupr_criteria_setting ) :
											?>
								<div class="multi-review">
									<div class="bupr-col-4 bupr-criteria-label">
												<?php echo esc_html( bupr_get_criteria_label( $bupr_rating_fields ) ); ?>
									</div>
									<div class="bupr-col-4 bupr-criteria-content" id="member_review<?php echo esc_attr( $field_counter ); ?>">
										<input type="hidden" id="<?php echo 'clicked' . esc_attr( $field_counter ); ?>" value="<?php echo esc_attr( 'not_clicked' ); ?>">
										<input type="hidden" name="member_rated_stars[]" id="member_rated_stars" class="member_rated_stars bupr-star-member-rating" id="<?php echo 'member_rated_stars' . esc_attr( $field_counter ); ?>" value="0">
												<?php	for ( $i = 1; $i <= 5; $i++ ) { ?>
											<span class="far member_stars member-star-<?php echo esc_attr( $i ); ?> fa-star bupr-stars bupr-star-rate" id="<?php echo esc_attr( $field_counter ) . esc_attr( $i ); ?>" data-attr="<?php echo esc_attr( $i ); ?>" ></span>
										<?php } ?>
									</div>
									<div class="bupr-col-12 bupr-error-fields">*<?php esc_html_e( 'This field is required.', 'bp-member-reviews' ); ?></div>
								</div>
												<?php
												++$field_counter;
										endforeach;
									}
									?>
					<input type="hidden" id="member_rating_field_counter" value="<?php echo esc_attr( --$field_counter ); ?>">
									<?php
								} else {
									$field_counter = 1;
									?>
									<div class="multi-review">
										<div class="bupr-col-4 bupr-criteria-label">
											<label><?php esc_html_e( 'Rating : ', 'bp-member-reviews' ); ?></label>
										</div>
										<div class="bupr-col-4 bupr-criteria-content" id="member_review<?php echo esc_attr( $field_counter ); ?>">
											<input type="hidden" id="<?php echo 'clicked' . esc_attr( $field_counter ); ?>" value="<?php echo esc_attr( 'not_clicked' ); ?>">
											<input type="hidden" name="member_rated_stars[]" id="member_rated_stars" class="member_rated_stars bupr-star-member-rating" id="<?php echo 'member_rated_stars' . esc_attr( $field_counter ); ?>" value="0">
													<?php	for ( $i = 1; $i <= 5; $i++ ) { ?>
												<span class="far member_stars member-star-<?php echo esc_attr( $i ); ?> fa-star bupr-stars bupr-star-rate" id="<?php echo esc_attr( $field_counter ) . esc_attr( $i ); ?>" data-attr="<?php echo esc_attr( $i ); ?>" ></span>
											<?php } ?>
										</div>
									</div>
										<input type="hidden" id="member_rating_field_counter" value="1">
									<?php
								}
							} else {
								// No rating fields (Testimonial Mode) - just add hidden counter with 0.
								?>
								<input type="hidden" id="member_rating_field_counter" value="0">
								<?php
							}

							/**
							 * Hook to add additional fields after rating criteria.
							 * Used by Pro addon for flexible criteria (thumbs, text fields).
							 *
							 * @since 3.8.0
							 */
							do_action( 'bupr_after_rating_fields' );
							?>
								<input type="hidden" id="bupr_member_review_id" value="<?php echo esc_attr( bp_displayed_user_id() ); ?>">
								<?php
								/*
								 * No review-subject field by design: the post_title is
								 * generated server-side in includes/bupr-ajax.php
								 * ( "%1$s received a %2$s" ). A permanently hidden
								 * "review-subject" input sat here until 2026-07-17; it
								 * was removed because no PHP or JS ever read its value.
								 */
								?>
								<label for="review_desc" class="screen-reader-text">
								<?php
								/* translators: %s: review label */
								printf( esc_html__( 'Enter your %s', 'bp-member-reviews' ), esc_html( strtolower( $bupr['review_label'] ) ) );
								?>
								</label>
								<textarea name="review-desc" id="review_desc" placeholder="<?php
								/* translators: %s: review label */
								echo esc_attr( sprintf( __( 'Enter your %s', 'bp-member-reviews' ), strtolower( $bupr['review_label'] ) ) );
								?>" rows="4" cols="50"></textarea><br/>
							<?php if ( $flag ) { ?>
									<p>
										<label for="bupr_anonymous_review"><input style="width:auto !important" type="checkbox" id="bupr_anonymous_review" value="value">
										<?php
										/* translators: %s: review label;  */
										printf( esc_html__( 'Send %s anonymously.', 'bp-member-reviews' ), esc_html( strtolower( $bupr['review_label'] ) ) );
										?>
										</label>
									</p>
							<?php } ?>
								<p>
							<div class="bupr-col-12 bupr-review-error-fields">*<?php esc_html_e( 'Please either select a rating or write a review.', 'bp-member-reviews' ); ?></div>
							<?php wp_nonce_field( 'save-bp-member-review', 'security-nonce' ); ?>

									<button type="button" class="button btn btn-default" id="bupr_save_review" name="submit-review">
									<?php
									/* translators: %s: */
									printf( esc_html__( 'Submit %s', 'bp-member-reviews' ), esc_html( $bupr['review_label'] ) );
									?>
									</button>
									<input type="hidden" value="<?php echo esc_attr( $login_user ); ?>" id="bupr_current_user_id" />
									<img src="<?php echo esc_url( $bupr_spinner_src ); ?>" class="bupr-save-reivew-spinner" alt="<?php esc_attr_e( 'Loading...', 'bp-member-reviews' ); ?>" />
								</p>
							</div>
						</form>
							<?php
						}
					}
		}
	}

	new BUPR_Shortcodes();
}
