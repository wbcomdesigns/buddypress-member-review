<?php // phpcs:ignore WordPress.Files.FileName.InvalidClassFileName
/**
 * Display Review Widget.
 *
 * @package BuddyPress_Member_Reviews
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'widgets_init', 'bupr_members_review_widget' );

/**
 * Register the BP Member Review widget.
 *
 * @return void
 */
function bupr_members_review_widget() {
	register_widget( 'bupr_members_review_setting' );
}

// phpcs:ignore PEAR.NamingConventions.ValidClassName.Invalid, PEAR.NamingConventions.ValidClassName.StartWithCapital, Universal.Files.SeparateFunctionsFromOO.Mixed
/**
 * BP Member Review Widget Class.
 *
 * Displays a list of members based on their reviews (top-rated or most-reviewed).
 *
 * @since 1.0.0
 */
// phpcs:ignore PEAR.NamingConventions.ValidClassName.Invalid, PEAR.NamingConventions.ValidClassName.StartWithCapital, Universal.Files.SeparateFunctionsFromOO.Mixed, Squiz.Commenting.ClassComment.Missing -- Legacy class name, cannot rename without breaking existing widget instances.
class bupr_members_review_setting extends WP_Widget {

	/**
	 * Constructor.
	 *
	 * Sets up the widget name, description, and control options.
	 */
	public function __construct() {
		$widget_ops  = array(
			'classname'   => 'bupr_members_review_setting',
			'description' => esc_html__( 'Display a list of members based on their reviews.', 'bp-member-reviews' ),
		);
		$control_ops = array(
			'width'   => 280,
			'height'  => 350,
			'id_base' => 'bupr_members_review_setting',
		);
		parent::__construct( 'bupr_members_review_setting', esc_html__( 'BP Member Review Widget', 'bp-member-reviews' ), $widget_ops, $control_ops );
	}

	/**
	 * Display the widget on the frontend.
	 *
	 * @param array $args     Widget display arguments including before/after widget and title.
	 * @param array $instance Widget instance settings.
	 * @return void
	 */
	public function widget( $args, $instance ) {
		// Extract widget wrapper variables explicitly instead of using extract().
		$before_widget = $args['before_widget'];
		$after_widget  = $args['after_widget'];
		$before_title  = $args['before_title'];
		$after_title   = $args['after_title'];

		global $wpdb;

		// Widget instance settings. `title` is the standard key; `bupr_title` is read for widgets saved before 3.8.3.
		$bupr_title   = apply_filters( 'widget_title', $instance['title'] ?? ( $instance['bupr_title'] ?? esc_html__( 'Top Rated Members', 'bp-member-reviews' ) ), $instance, $this->id_base );
		$member_limit = isset( $instance['bupr_member'] ) ? (int) $instance['bupr_member'] : 20; // Limit to 20 members by default.
		$top_member   = isset( $instance['top_member'] ) ? $instance['top_member'] : 'top-rated';
		$avatar       = isset( $instance['avatar'] ) ? $instance['avatar'] : 'Show';

		// Same last-changed token as [bupr_display_top_members]: bupr_flush_top_members_cache() moves it whenever ratings change.
		$cache_key = 'widget_' . md5( $top_member . '|' . $member_limit ) . ':' . wp_cache_get_last_changed( 'bupr_top_members' );
		$results   = wp_cache_get( $cache_key, 'bupr_top_members' );
		if ( false === $results ) {
			$results = array();
			// Top Rated sorts by aggregate rating, Most Reviewed by review count (fixed SQL fragments, never user input).
			$order_by = array(
				'top-rated'  => 'CAST(um1.meta_value AS DECIMAL(10,2))',
				'top-viewed' => 'CAST(um2.meta_value AS UNSIGNED)',
			);
			if ( isset( $order_by[ $top_member ] ) ) {
				// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Cached in the object cache above; ORDER BY is a whitelisted literal.
				$results = $wpdb->get_results(
					$wpdb->prepare(
						"SELECT um1.user_id, um1.meta_value AS aggregate_rating, um2.meta_value AS review_count
						FROM $wpdb->usermeta AS um1
						JOIN $wpdb->usermeta AS um2 ON um1.user_id = um2.user_id
						WHERE um1.meta_key = 'bupr_aggregate_rating'
						AND um2.meta_key = 'bupr_review_count'
						AND CAST(um2.meta_value AS UNSIGNED) > 0
						ORDER BY {$order_by[ $top_member ]} DESC
						LIMIT %d",
						$member_limit
					)
				);
				// phpcs:enable
			}
			wp_cache_set( $cache_key, $results, 'bupr_top_members', 15 * MINUTE_IN_SECONDS );
		}

		echo $before_widget; // phpcs:ignore.
		if ( '' !== (string) $bupr_title ) {
			echo $before_title . esc_html( $bupr_title ) . $after_title; // phpcs:ignore.
		}

		// Check if any users were found.
		if ( ! empty( $results ) ) {
			cache_users( wp_list_pluck( $results, 'user_id' ) );
			echo '<ul class="bupr-member-main">';

			// Loop through the results and display them.
			foreach ( $results as $user ) {
				$user_id          = $user->user_id;
				$aggregate_rating = round( floatval( $user->aggregate_rating ), 2 );
				$review_count     = intval( $user->review_count );

				// Display user avatar and rating.
				echo '<li class="bupr-members">';
				if ( 'Show' === $avatar ) {
					echo '<div class="bupr-img-widget">' . get_avatar( $user_id, 50 ) . '</div>';
				}
				echo '<div class="bupr-content-widget">';
                echo '<div class="bupr-member-title">' . bp_core_get_userlink( $user_id ) . '</div>'; // phpcs:ignore.
				/**
				 * Filter whether to show star ratings in widget.
				 * Pro addon sets this to false for Testimonial/Endorsement modes.
				 *
				 * @since 3.8.0
				 * @param bool $show_stars Whether to display star ratings. Default true.
				 */
				$show_stars = apply_filters( 'bupr_widget_show_stars', true );

				/**
				 * Filter the item type label (reviews/testimonials/endorsements).
				 * Pro addon changes this based on review mode.
				 *
				 * @since 3.8.0
				 * @param string $label The item type label. Default 'reviews'.
				 * @param int    $count Review count, for choosing singular or plural (since 3.8.1).
				 */
				$item_label = apply_filters( 'bupr_item_type_label', _n( 'review', 'reviews', (int) $review_count, 'bp-member-reviews' ), (int) $review_count );

				if ( $show_stars ) {
					echo '<div class="bupr-member-rating">';

					// Star rating visualization (Fixed 5 stars, consistent display).
					$stars_on   = floor( $aggregate_rating );
					$stars_half = ( $aggregate_rating - $stars_on >= 0.5 ) ? 1 : 0;
					$stars_off  = 5 - ( $stars_on + $stars_half );

					// Display stars.
					for ( $i = 0; $i < $stars_on; $i++ ) {
						echo '<span class="fas fa-star bupr-star-rate"></span>';
					}
					if ( $stars_half ) {
						echo '<span class="fas fa-star-half-alt bupr-star-rate"></span>';
					}
					for ( $i = 0; $i < $stars_off; $i++ ) {
						echo '<span class="far fa-star bupr-star-rate"></span>';
					}

					echo '</div>';
					/* translators: %1$s: aggregate rating; %2$s: Review count; %3$s: item type label */
					echo '<span class="bupr-meta">' . sprintf( esc_html__( '%1$s/5 (%2$s %3$s)', 'bp-member-reviews' ), esc_html( $aggregate_rating ), esc_html( $review_count ), esc_html( $item_label ) ) . '</span>';
				} else {
					/* translators: %1$s: Review count; %2$s: item type label */
					echo '<span class="bupr-meta">' . sprintf( esc_html__( '%1$s %2$s', 'bp-member-reviews' ), esc_html( $review_count ), esc_html( $item_label ) ) . '</span>';
				}
				echo '</div></li>';
			}

			echo '</ul>';
		} else {
			echo '<p class="bupr-widget-empty">' . esc_html__( 'No members have been reviewed yet.', 'bp-member-reviews' ) . '</p>';
		}
		echo $after_widget; // phpcs:ignore.
	}

	/**
	 * Update widget settings when saved in admin.
	 *
	 * @param array $new_instance New settings for this widget instance.
	 * @param array $old_instance Old settings for this widget instance.
	 * @return array Updated settings to save.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance                = $old_instance;
		$instance['title']       = wp_strip_all_tags( $new_instance['title'] ?? '' );
		$instance['bupr_member'] = intval( $new_instance['bupr_member'] );
		$instance['top_member']  = wp_strip_all_tags( $new_instance['top_member'] );
		$instance['avatar']      = wp_strip_all_tags( $new_instance['avatar'] );
		unset( $instance['bupr_title'] ); // Legacy key, replaced by `title`.
		return $instance;
	}

	/**
	 * Display the widget settings form in the admin.
	 *
	 * @param array $instance Current settings for this widget instance.
	 * @return void
	 */
	public function form( $instance ) {
		$defaults   = array(
			'title'       => $instance['bupr_title'] ?? esc_html__( 'Top Members', 'bp-member-reviews' ),
			'bupr_member' => 20,
			'top_member'  => 'top-rated',
			'avatar'      => 'Show',
		);
		$instance   = wp_parse_args( (array) $instance, $defaults );
		$title      = esc_attr( $instance['title'] );
		$member     = esc_attr( $instance['bupr_member'] );
		$topmembers = esc_attr( $instance['top_member'] );
		$avatar     = esc_attr( $instance['avatar'] );
		?>
		<div class="bupr-widget-class">
			<p>
				<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Enter Title', 'bp-member-reviews' ); ?>:</label>
				<input class="regular_text" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
			</p>
			<p>
				<label for="<?php echo esc_attr( $this->get_field_id( 'bupr_member' ) ); ?>"><?php esc_html_e( 'Display Members', 'bp-member-reviews' ); ?>:</label>
				<input class="regular_text" id="<?php echo esc_attr( $this->get_field_id( 'bupr_member' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'bupr_member' ) ); ?>" type="number" value="<?php echo esc_attr( $member ); ?>" />
			</p>

			<p>
				<span>
					<input class="regular_text" id="<?php echo esc_attr( $this->get_field_id( 'top_rated' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'top_member' ) ); ?>" value="top-rated" type="radio" <?php checked( $topmembers, 'top-rated' ); ?> />
					<label for="<?php echo esc_attr( $this->get_field_id( 'top_rated' ) ); ?>"><?php esc_html_e( 'Top Rated ', 'bp-member-reviews' ); ?>
					</label>
				</span>
				<span>
					<input class="regular_text" id="<?php echo esc_attr( $this->get_field_id( 'top_viewed' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'top_member' ) ); ?>" value="top-viewed" type="radio" <?php checked( $topmembers, 'top-viewed' ); ?> />
					<label for="<?php echo esc_attr( $this->get_field_id( 'top_viewed' ) ); ?>"><?php esc_html_e( 'Most Reviewed', 'bp-member-reviews' ); ?>
					</label>
				</span>
			</p>

			<p>
				<label for="<?php echo esc_attr( $this->get_field_id( 'avatar' ) ); ?>"><?php esc_html_e( 'Display Avatar ', 'bp-member-reviews' ); ?>
				</label>
				<?php
				$bupr_options = array( 'Show', 'Hide' );
				?>
				<select id="<?php echo esc_attr( $this->get_field_id( 'avatar' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'avatar' ) ); ?>">
					<?php
					foreach ( $bupr_options as $bupr_option ) {
						?>
						<option value="<?php echo esc_attr( $bupr_option ); ?>" <?php selected( $avatar, $bupr_option ); ?>><?php echo esc_html( $bupr_option ); ?></option>
						<?php
					}
					?>
				</select>
			</p>
		</div>
		<?php
	}
}
