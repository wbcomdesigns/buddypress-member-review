<?php
/**
 * BuddyPress Member Review display tab.
 *
 * @package BuddyPress_Member_Reviews
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
global $bupr;
?>
<div class="wbcom-tab-content">
	<div class="wbcom-admin-title-section">
		<h3><?php esc_html_e( 'Display Settings', 'bp-member-reviews' ); ?></h3>
	</div>
	<div class="wbcom-admin-option-wrap wbcom-admin-option-wrap-view">
		<form method="post" action="options.php">
			<?php
			settings_fields( 'bupr_admin_display_options' );
			do_settings_sections( 'bupr_admin_display_options' );
			?>
			<div class="form-table">	
				<div class="wbcom-settings-section-wrap ">
					<div class="wbcom-settings-section-options-heading">
						<label for="bupr_member_tab_title">
							<?php esc_html_e( 'Review Label', 'bp-member-reviews' ); ?>
						</label>
						<p class="description">
							<?php esc_html_e( 'Label used in the profile tab and review form.', 'bp-member-reviews' ); ?>
						</p>
					</div>
					<div class="wbcom-settings-section-options">
						<input type="text" name="bupr_admin_display_options[bupr_review_title]" id="bupr_member_tab_title" value="<?php echo esc_attr( $bupr['review_label'] ); ?>">
					</div>
				</div>
				<div class="wbcom-settings-section-wrap ">
					<div class="wbcom-settings-section-options-heading">
						<label for="bupr_member_tab_title_plural">
							<?php esc_html_e( 'Reviews Label (Plural)', 'bp-member-reviews' ); ?>
						</label>
						<p class="description">
							<?php esc_html_e( 'Plural form of the review label.', 'bp-member-reviews' ); ?>
						</p>
					</div>
					<div class="wbcom-settings-section-options">
						<input type="text" name="bupr_admin_display_options[bupr_review_title_plural]" id="bupr_member_tab_title_plural" value="<?php echo esc_attr( $bupr['review_label_plural'] ); ?>">
					</div>
				</div>
			</div>
			<div class="wbcom-admin-title-section">
				<h3><?php esc_html_e( 'Colors', 'bp-member-reviews' ); ?></h3>
			</div>
			<div class="form-table">
				<div class="wbcom-settings-section-wrap ">
					<div class="wbcom-settings-section-options-heading">
						<label for="bupr_display_color">
							<?php esc_html_e( 'Rating Color', 'bp-member-reviews' ); ?>
						</label>
						<p class="description">
							<?php esc_html_e( 'This option allows you to change the star rating color.', 'bp-member-reviews' ); ?>
						</p>
					</div>
					<div class="wbcom-settings-section-options">
						<input type="text" name="bupr_admin_display_options[bupr_star_color]" id="bupr_display_color" class="bupr-admin-color-picker" value="<?php echo esc_attr( $bupr['rating_color'] ); ?>">
					</div>
				</div>
			</div>
			<?php submit_button(); ?>
		</form>
	</div>					
</div>
